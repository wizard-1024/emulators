#!/bin/sh

# clean all
rm -f *.lst *.out *.cdp *.err *.txt
exit 0

